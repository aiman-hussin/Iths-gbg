﻿using System;

namespace Lab4ClassLibrary
{
    public class Word
    {
        public string[] Translations { get; }
        public int FromLanguage { get; }
        public int ToLanguage { get; }

        public Word(params string[] translations)
        {
            string[] trans = new string[translations.Length];
            for (int i = 0; i < translations.Length; i++)
            {
                trans[i] = (string)translations[i].Clone();
            }
            Translations = trans;
        }
        public Word(int fromLanguage, int toLanguage,
            params string[] translations)
        {
            string[] trans = new string[translations.Length];
            FromLanguage = fromLanguage;
            ToLanguage = toLanguage;
            for (int i = 0; i < translations.Length; i++)
            {
                trans[i] = (string)translations[i].Clone();
            }
            Translations = trans;
        }
    }
}
