﻿using System;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using Lab4ClassLibrary;
using System.Text.RegularExpressions;

namespace Lab4
{
    static class Program
    {
        private static string listsPath =
            Environment.GetFolderPath(
            Environment.SpecialFolder.LocalApplicationData) + @"\Lab4\";
        static WordList wordList;
        static void Main(string[] args)
        {
            if (!Directory.Exists(listsPath))
                Directory.CreateDirectory(listsPath);

            string menu = "Use any of the following parameters:\n" +
                        "-lists\n" +
                        "-new <list name> <language 1> <language 2> .. <language n>\n" +
                        "-add <list name>\n" +
                        "-remove <list name> <language> <word 1> <word 2> .. <word n>\n" +
                        "-words <listname> <sortByLanguage>\n" +
                        "-count <listname>\n" +
                        "-practice <listname>";

            if (args.Length == 0)
            {
                Console.WriteLine(menu);
            }
            else
            {
                try
                {
                    switch (args[0].ToLower())
                    {
                        case ("-lists"):
                            Array.ForEach(WordList.GetLists(), x => Console.WriteLine(x));
                            break;
                        case ("-new"):
                            NewList(args);
                            break;
                        case ("-add"):
                            wordList = WordList.LoadList(args[1]);
                            Add(wordList.Languages);

                            break;
                        case ("-remove"):
                            RemoveWord(args);
                            break;
                        case ("-words"):
                            wordList = WordList.LoadList(args[1]);
                            int langIndx = 0;
                            if (args.Length > 2)
                            {
                                if (wordList.Languages.Contains(args[2].ToLower()))
                                    langIndx = Array.IndexOf(wordList.Languages, args[2].ToLower());
                            }
                            ShowAllWords(langIndx, wordList);
                            break;
                        case ("-count"):
                            wordList = WordList.LoadList(args[1]);
                            Console.WriteLine(wordList.Count());
                            break;
                        case ("-practice"):
                            Practice(args[1]);
                            break;
                        default:
                            Console.WriteLine(menu);
                            break;
                    }
                }
                catch (IOException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                    //Console.WriteLine(menu);
                }
                catch (IndexOutOfRangeException)
                {
                    Console.WriteLine(menu);
                }
                catch (Exception)
                {
                    //Console.WriteLine(e.Message);
                    //Console.WriteLine(e.StackTrace);
                    Console.WriteLine(menu);
                }
            }
        }

        //****************************
        private static int NewList(string[] args)
        {
            string[] langs = new string[args.Length - 2];
            for (int i = 2; i < args.Length; i++)
            {
                langs[i - 2] = args[i].Clone().ToString().ToLower();
            }

            if (langs.Length < 2)
            {
                throw new Exception(); //less than two languages -> show the menu
            }

            string s = string.Join(';', langs);

            //I didn't find any language consists of two separate words
            //or contains symbols like - ' etc. The following condition
            //can be changed if there are such languages
            s = Regex.Replace(s, "\\s+", "");
            if (!Regex.IsMatch(s, "^[\\p{L};-]+$"))
            {
                Console.WriteLine("Only letters, ; and - are allowed for languages");
                return 0;
            }

            string[] lans = s.Split(';');

            if (lans.Length != lans.Distinct().Count())
            {
                Console.WriteLine("You can't enter the same language more than once");
                return 0;
            }

            try
            {
                File.WriteAllText(listsPath + args[1] + ".dat", s);
                wordList = WordList.LoadList(args[1]);
                Add(lans);
            }
            catch (IOException e)
            {
                throw new IOException(e.Message);
            }
            return 0;
        }

        //****************************
        private static int Add(string[] langs)
        {
            List<string> inputList = new List<string>();
            List<string> wordsToAdd = new List<string>();
            string newWord = "";
            while (true)
            {
                Console.WriteLine($"Enter a new word in {langs[0].Capitalize()}:");
                newWord = Console.ReadLine();

                if ((string.IsNullOrEmpty(newWord) ||
                     string.IsNullOrWhiteSpace(newWord)) &&
                     wordsToAdd.Count == 0)
                {
                    return 0; //cancel if no new words were entered
                }
                if (string.IsNullOrEmpty(newWord) ||
                    string.IsNullOrWhiteSpace(newWord))
                {
                    break;
                }
                
                if (!Regex.IsMatch(newWord, "^[\\s\\p{L}-']+$"))
                {
                    Console.WriteLine("A word only can contain letters, - and '");
                    continue;
                }

                inputList.Add(newWord);

                for (int i = 1; i < langs.Length; i++)
                {
                    string input = "";

                    while (true)
                    {
                        Console.WriteLine($"Enter a translation for " +
                                          $"'{newWord}' in {langs[i].Capitalize()}");
                        input = Console.ReadLine();

                        //if the user enters an empty translation, the procedure
                        //will be canceled
                        if (string.IsNullOrWhiteSpace(input) ||
                        string.IsNullOrEmpty(input))
                        {
                            return 0;
                        }

                        if (Regex.IsMatch(input, "^[\\s\\p{L}-']+$"))
                        {
                            break;
                        }
                        else
                        {
                            Console.WriteLine("A word only can contain letters, - and '");
                        }
                    }
                    inputList.Add(input);
                }
                wordsToAdd.Add(string.Join(';', inputList));
                inputList.Clear();
            }
            wordList.Add(wordsToAdd.ToArray());
            return 0;
        }

        //****************************
        private static int RemoveWord(string[] args)
        {
            string listName = args[1];
            string language = args[2];
            string[] words = new string[args.Length - 3];
            //get the words to be deleted from args
            Array.Copy(args.Skip(3).ToArray(), words, words.Length);

            if (words.Length < 1)//If no words were provided throw an exception -> display the commands menu
                throw new Exception();

            wordList = WordList.LoadList(listName);

            if (!wordList.Languages.Contains(language))
            {
                Console.WriteLine("The provided language was not found");
                return 0;
            }

            foreach (string lang in wordList.Languages.Where(x =>
             x.ToLower().Equals(language.ToLower())))
            {
                foreach (string word in words)
                {
                    if (wordList.Remove(Array.IndexOf(wordList.Languages, lang), word))
                    {
                        Console.WriteLine($"The word '{word}' was deleted");
                    }
                    else
                    {
                        Console.WriteLine($"The word '{word}' was not found in" +
                            $" {lang.Capitalize()} translations");
                    }
                }
            }
            return 0;
        }

        //****************************
        private static void ShowAllWords(int i, WordList words)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            foreach (string s in words.Languages)
            {
                Console.Write("|".PadRight(5) + s.PadRight(10).Capitalize() + "|");
            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine();
            words.List(i, trans =>
            {
                foreach (string s in trans)
                {
                    Console.Write("|".PadRight(5) + s.ToLower().PadRight(10) + "|");
                }
                Console.WriteLine();
            });
        }

        //****************************
        private static void Practice(string listName)
        {
            int allPracticedWords = 0, correctTranslation = 0;

            wordList = WordList.LoadList(listName);

            while (true)
            {
                Word word = wordList.GetWordToPractice();
                Console.WriteLine($"Translate '{word.Translations[word.FromLanguage]}'" +
                    $" to {wordList.Languages[word.ToLanguage].Capitalize()}:");
                string newWord = Console.ReadLine();
                if (string.IsNullOrEmpty(newWord) || string.IsNullOrWhiteSpace(newWord))
                {
                    break;
                }

                allPracticedWords++;

                if (newWord.ToLower().Equals(word.Translations[word.ToLanguage].ToLower()))
                {
                    correctTranslation++;
                }
            }

            if (allPracticedWords == 0)
            {
                Console.WriteLine("You didn't practice any word");
            }
            else
            {
                float percent = correctTranslation * 100 / allPracticedWords;
                Console.WriteLine($"You have practiced {allPracticedWords} words, " +
                                  $"{percent}% of you answers " +
                                   $"were correct");
            }
        }

        //Capitalize the first letter of a word
        static string Capitalize(this string str)
        {
            string s = "";
            if (str.Length > 0)
            {
                str = str.ToLower();
                char[] ch = str.ToArray();
                s += ch[0].ToString().ToUpper();
                s += string.Join("", ch.Skip(1));
            }
            return s;
        }
    }
}