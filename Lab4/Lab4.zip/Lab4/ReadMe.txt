Förslag:

-Varna användaren om det redan finns en lista med samma namn som den nya skapade listan och hantera användarens val
-Möjligheten att ändra sökvägen så att filer sparas i en valfri mapp
-Möjlighten att ta bort listor
-Göra om konsolapp så att den blir meny baserad via en while-loop så att man inte behöver mata in arguments varje gång man vill göra någonting med appen då man behöver interact med en sån app flera gånger per session
-En ny funktion för Practice med fallande/blinkande ord där användare bör mata in orden innan de når botten/försvinner
-En ny funktion som visar info om listor såsom size, created date, included languages ...osv
-För att Load funktion ska funka måste List <Word> deklareras statisk, detta skapar förvirringar 'i mitt fall åtminståne', det skulle ha varit lättare om man kan instansiera en WordList utan statiska metoder eller fält, designen av classLibrary behöver ändras i så fall
-En funktion som kontrollerar om data format och allt stämmer i sparade .dat filer innan load
-Kontrollera om ett ord och dess översättningar finns redan i lisan innan och varna användaren

Tiduppskattning:
-ClassLibrary: ca. ett par timmar arbete
-Konsolapp: ca. 4 timmars arbete
-Winform app: ca 5 timmars arbete
-Ca. en timmes till flera timmars arbete för testning och bug fixing tillkommer för varje app respektive, tiden varierar beroende på vad som dyker upp och hur många scenarier som koden hanterar

Övrigt:
När du har gått igenom min lösning, tipsa gärna om vad som ska jag tänka på för att förbättra min kod/lösning och låta den se mer avancerad ut, gärna med exampel från min kod.