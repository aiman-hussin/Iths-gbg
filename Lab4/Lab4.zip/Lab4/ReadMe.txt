Förslag:

-Varna användaren om det redan finns en lista med samma namn som den nya skapade listan och hantera användarens val
-Möjligheten att ändra sökvägen så att filer sparas i en valfri mapp
-Möjlighten att ta bort listor
-Göra om konsolapp så att den blir meny baserad via en while-loop så att man inte behöver mata in arguments varje gång man vill göra någonting med appen då man behöver interact med en sån app flera gånger per session
-En ny funktion för Practice med fallande/blinkande ord där användare bör mata in orden innan de når botten/försvinner
-En ny funktion som visar info om listor såsom size, created date, included languages ...osv
-För att Load funktion ska funka måste List <Word> deklareras statisk, detta skapar förvirringar 'i mitt fall åtminståne', det skulle ha varit lättare om man kan instansiera en WordList utan statiska metoder eller fält, designen av classLibrary behöver ändras i så fall
-En funktion som kontrollerar om data format och allt stämmer i sparade .dat filer innan load
-Kontrollera om ett nytt ord och dess översättningar finns redan i lisan och varna / förhindra användaren att lägga till det

Tiduppskattning:
-ClassLibrary: ca. ett par timmar arbete
-Konsolapp: ca. 4 timmars arbete
-Winform app: ca 5 timmars arbete
-Mellan en timmes till flera timmars arbete för testning och bug fixing tillkommer för varje app respektive, tiden varierar beroende på vad som dyker upp och hur många scenarier koden hanterar

Övrigt:
Du har två olika fileformat i dina exampel filer, i några av de slutar ord och språk med en semicolon och andra såsom i filen sv-SE_en-US.dat gör det inte det. Jag går med att inte lägga någon semicolon i slutet av ord/språk men programmet klarar att läsa de filer som slutar med semicolon så det går bra att testa dem om man vill.

När du har gått igenom min lösning, tipsa gärna om vad som ska jag tänka på för att förbättra min kod/lösning och låta den se mer avancerad ut, gärna med exampel från min kod.