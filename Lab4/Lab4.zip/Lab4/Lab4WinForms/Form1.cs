﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Lab4ClassLibrary;
using Microsoft.VisualBasic;

namespace Lab4WinForms
{
    public partial class Form1 : Form
    {
        private WordList wordList;
        private static string listsPath =
            Environment.GetFolderPath(
            Environment.SpecialFolder.LocalApplicationData) + @"\Lab4\";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (!Directory.Exists(listsPath))
                Directory.CreateDirectory(listsPath);

            lblListsPath.Text = "Lists folder: " + listsPath;
            ListBoxRefresh(false, null);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddWords(listBox.SelectedItem.ToString());
        }

        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            WordList wordList = WordList.LoadList(
                listBox.SelectedItem.ToString());
            SetDataTable(0, wordList);
            this.wordList = wordList;
        }

        private void btnPractice_Click(object sender, EventArgs e)
        {
            Practice(listBox.SelectedItem.ToString());
        }

        private void btnAddList_Click(object sender, EventArgs e)
        {
            AddList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ListBoxRefresh(false, null);
        }

        private void ListBoxRefresh(bool newList, string listName)
        {
            listBox.Items.Clear();
            Array.ForEach(WordList.GetLists(), x => listBox.Items.Add(x));

            if (newList)
            {   //select the newly created list
                for (int i = 0; i < listBox.Items.Count; i++)
                {
                    if (listBox.Items[i].ToString() == listName)
                        listBox.SetSelected(i, true);
                }
            }
            else
            {   // select first item on form load if there are any
                if (listBox.Items.Count > 0)
                    listBox.SetSelected(0, true);
            }
        }

        private void combSort_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetDataTable(combSort.SelectedIndex, wordList);
        }

        private void btnRemoveWord_Click(object sender, EventArgs e)
        {
            if (dataGrid.SelectedCells.Count > 0)
            {
                WordList wordList = WordList.LoadList(listBox.SelectedItem.ToString());
                wordList.Remove(dataGrid.SelectedCells[0].ColumnIndex,
                    dataGrid.SelectedCells[0].Value.ToString());

                //refill the data table after deleting a word
                int i = listBox.SelectedIndex;
                listBox.Refresh();
                listBox.SetSelected(i, true);
            }
            else
            {
                MessageBox.Show("Select a word to delete", "Delete a word");
            }
        }

        private int AddWords(string listName)
        {
            WordList wordList = WordList.LoadList(listName);
            List<string> inputList = new List<string>();
            List<string> wordsToAdd = new List<string>();

            while (true)
            {
                string newWord = Interaction.InputBox(
                    $"Enter a new word in {Capitalize(wordList.Languages[0])}:",
                    "New Word", "");

                if ((string.IsNullOrEmpty(newWord) ||
                    string.IsNullOrWhiteSpace(newWord)) &&
                    wordsToAdd.Count == 0)
                {
                    return 0;
                }
                if (string.IsNullOrEmpty(newWord) ||
                     string.IsNullOrWhiteSpace(newWord))
                {
                    break;
                }

                newWord = Regex.Replace(newWord, @"\s+", "");
                if (!Regex.IsMatch(newWord, "^[\\p{L}-]+$"))
                {
                    MessageBox.Show("A word only can contain letters and -",
                        "New word");
                    continue;
                }

                inputList.Add(newWord);

                for (int i = 1; i < wordList.Languages.Length; i++)
                {
                    string input = "";
                    while (true)
                    {
                        input = Interaction.InputBox($"Enter a translation for " +
                                        $"'{newWord}' in {Capitalize(wordList.Languages[i])}",
                                        "New word", "");
                        //if the user enters an empty translation, the procedure
                        //will be canceled
                        if (string.IsNullOrWhiteSpace(input) ||
                            string.IsNullOrEmpty(input))
                        {
                            return 0;
                        }

                        input = Regex.Replace(input, @"\s+", "");
                        if (Regex.IsMatch(input, "^[\\p{L}-]+$"))
                        {
                            break;
                        }
                        else
                        {
                            MessageBox.Show("A word only can contain letters and -,",
                                "New word");
                        }
                    }
                    inputList.Add(input);
                }
                wordsToAdd.Add(string.Join(';', inputList).ToString());
                inputList.Clear();
            }
            wordList.Add(wordsToAdd.ToArray());

            //refresh the data table
            ListBoxRefresh(true, listName);
            for (int i = 0; i < listBox.Items.Count; i++)
            {
                if (listBox.Items[i].ToString() == wordList.Name)
                    listBox.SetSelected(i, true);
            }

            return 0;
        }

        private int AddList()
        {
            string listName = Interaction.InputBox("Enter list name",
                "New list", "").Trim();

            if (string.IsNullOrEmpty(listName) ||
                string.IsNullOrWhiteSpace(listName))
            {
                return 0;
            }
            string lang = Interaction.InputBox(
                "Enter languages in format lang1;lang2;  ....;langN",
                 "New list", "");

            if (lang == "")
                return 0;

            if (lang.StartsWith(';') || lang.EndsWith(';'))
            {
                MessageBox.Show("Wrong languages format", "New list");
                return 0;
            }
            if (!Regex.IsMatch(lang, "^[\\p{L};]+$"))
            {
                MessageBox.Show("Only letters and ';' are allowed for languages, " +
                    "whitespaces are not allowed", "New list");
                return 0;
            }

            string[] langs = Array.ConvertAll(lang.Split(';'), s => s.Trim()).Distinct().ToArray();

            if (langs.Length <= 1)
            {
                MessageBox.Show("You must enter minimum two languages",
                    "New list");
                return 0;
            }

            if (langs.Count() != langs.Distinct().Count())
            {
                MessageBox.Show("You can enter a language only once");
                return 0;
            }

            try
            {
                File.WriteAllText(listsPath + listName + ".dat", lang);

                ListBoxRefresh(true, listName);

                AddWords(listName);
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }

            return 0;
        }

        private void SetDataTable(int sort, WordList wordList)
        {
            DataTable dataTable = new DataTable();

            combSort.Items.Clear();
            for (int i = 0; i < wordList.Languages.Length; i++)
            {
                dataTable.Columns.Add(wordList.Languages[i].ToUpper());
                combSort.Items.Add(Capitalize(wordList.Languages[i]));
            }

            wordList.List(sort, trans =>
            {
                string[] row = new string[trans.Length];
                int i = 0;
                foreach (string s in trans)
                {
                    row[i] = s.ToLower();
                    i++;
                }
                dataTable.Rows.Add(row);
            });

            dataGrid.DataSource = dataTable;

            //disable / enable buttons
            if (dataTable.Columns.Count > 1)
            {
                btnAddWord.Enabled = true;
            }
            else
            {
                btnAddWord.Enabled = false;
            }
            if (dataTable.Rows.Count > 0)
            {
                btnRemoveWord.Enabled = true;
            }
            else
            {
                btnRemoveWord.Enabled = false;
            }
            if (dataTable.Columns.Count > 1 && dataTable.Rows.Count > 0)
            {
                btnPractice.Enabled = true;
            }
            else
            {
                btnPractice.Enabled = false;
            }

            //The Count method in WordList invokes here
            lblWords.Text = wordList.Count().ToString() + " words in " +
                listBox.SelectedItem.ToString();
        }

        private void Practice(string listName)
        {
            int allPracticedWords = 0, correctTranslation = 0;
            WordList wordList = WordList.LoadList(listName);
            lblPracticing.Visible = true;
            while (true)
            {
                Word word = wordList.GetWordToPractice();

                string newWord = Interaction.InputBox(
                    $"Translate '{word.Translations[word.FromLanguage]}'" +
                    $" to {Capitalize(wordList.Languages[word.ToLanguage])}:", "");
                if (string.IsNullOrEmpty(newWord) ||
                    string.IsNullOrWhiteSpace(newWord))
                {
                    break;
                }

                allPracticedWords++;

                if (newWord.ToLower().Equals(
                    word.Translations[word.ToLanguage].ToLower()))
                {
                    correctTranslation++;
                }
            }

            if (allPracticedWords == 0)
            {
                MessageBox.Show("You didn't practice any word", "Practice");
            }
            else
            {
                float percent = correctTranslation * 100 / allPracticedWords;
                MessageBox.Show($"You have practiced " +
                    $"{allPracticedWords} words, {percent}% of your answers were correct",
                    "Practice");
            }
            lblPracticing.Visible = false;
        }

        //Capitalize the first letter of a word
        private static string Capitalize(string str)
        {
            string s = "";
            if (str.Length > 0)
            {
                str = str.Trim().ToLower();
                char[] ch = str.ToArray();
                s += ch[0].ToString().ToUpper();
                s += string.Join("", ch.Skip(1));
            }
            return s;
        }

    }
}