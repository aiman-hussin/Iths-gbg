﻿
namespace Lab4WinForms
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddList = new System.Windows.Forms.Button();
            this.btnAddWord = new System.Windows.Forms.Button();
            this.btnRemoveWord = new System.Windows.Forms.Button();
            this.btnPractice = new System.Windows.Forms.Button();
            this.lblWords = new System.Windows.Forms.Label();
            this.dataGrid = new System.Windows.Forms.DataGridView();
            this.combSort = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblPracticing = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lblListsPath = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 15;
            this.listBox.Location = new System.Drawing.Point(40, 38);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(152, 154);
            this.listBox.TabIndex = 0;
            this.listBox.SelectedIndexChanged += new System.EventHandler(this.listBox_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Lists";
            // 
            // btnAddList
            // 
            this.btnAddList.Location = new System.Drawing.Point(40, 198);
            this.btnAddList.Name = "btnAddList";
            this.btnAddList.Size = new System.Drawing.Size(75, 23);
            this.btnAddList.TabIndex = 2;
            this.btnAddList.Text = "New list";
            this.btnAddList.UseVisualStyleBackColor = true;
            this.btnAddList.Click += new System.EventHandler(this.btnAddList_Click);
            // 
            // btnAddWord
            // 
            this.btnAddWord.Enabled = false;
            this.btnAddWord.Location = new System.Drawing.Point(207, 198);
            this.btnAddWord.Name = "btnAddWord";
            this.btnAddWord.Size = new System.Drawing.Size(75, 23);
            this.btnAddWord.TabIndex = 4;
            this.btnAddWord.Text = "Add";
            this.btnAddWord.UseVisualStyleBackColor = true;
            this.btnAddWord.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnRemoveWord
            // 
            this.btnRemoveWord.Enabled = false;
            this.btnRemoveWord.Location = new System.Drawing.Point(288, 198);
            this.btnRemoveWord.Name = "btnRemoveWord";
            this.btnRemoveWord.Size = new System.Drawing.Size(75, 23);
            this.btnRemoveWord.TabIndex = 5;
            this.btnRemoveWord.Text = "Delete";
            this.btnRemoveWord.UseVisualStyleBackColor = true;
            this.btnRemoveWord.Click += new System.EventHandler(this.btnRemoveWord_Click);
            // 
            // btnPractice
            // 
            this.btnPractice.Enabled = false;
            this.btnPractice.Location = new System.Drawing.Point(414, 198);
            this.btnPractice.Name = "btnPractice";
            this.btnPractice.Size = new System.Drawing.Size(75, 23);
            this.btnPractice.TabIndex = 6;
            this.btnPractice.Text = "Practice";
            this.btnPractice.UseVisualStyleBackColor = true;
            this.btnPractice.Click += new System.EventHandler(this.btnPractice_Click);
            // 
            // lblWords
            // 
            this.lblWords.AutoSize = true;
            this.lblWords.Location = new System.Drawing.Point(207, 17);
            this.lblWords.Name = "lblWords";
            this.lblWords.Size = new System.Drawing.Size(176, 15);
            this.lblWords.TabIndex = 12;
            this.lblWords.Text = "Words count will be shown here";
            // 
            // dataGrid
            // 
            this.dataGrid.AllowUserToAddRows = false;
            this.dataGrid.AllowUserToDeleteRows = false;
            this.dataGrid.AllowUserToResizeColumns = false;
            this.dataGrid.AllowUserToResizeRows = false;
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Location = new System.Drawing.Point(207, 38);
            this.dataGrid.MultiSelect = false;
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.RowTemplate.Height = 25;
            this.dataGrid.Size = new System.Drawing.Size(416, 154);
            this.dataGrid.TabIndex = 13;
            // 
            // combSort
            // 
            this.combSort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combSort.FormattingEnabled = true;
            this.combSort.Location = new System.Drawing.Point(539, 9);
            this.combSort.Name = "combSort";
            this.combSort.Size = new System.Drawing.Size(84, 23);
            this.combSort.TabIndex = 14;
            this.combSort.SelectedIndexChanged += new System.EventHandler(this.combSort_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(489, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 15);
            this.label2.TabIndex = 15;
            this.label2.Text = "Sort by";
            // 
            // lblPracticing
            // 
            this.lblPracticing.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPracticing.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblPracticing.Location = new System.Drawing.Point(207, 38);
            this.lblPracticing.Name = "lblPracticing";
            this.lblPracticing.Size = new System.Drawing.Size(416, 154);
            this.lblPracticing.TabIndex = 16;
            this.lblPracticing.Text = "Practicing ...";
            this.lblPracticing.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPracticing.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(117, 198);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 17;
            this.button1.Text = "Refresh";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblListsPath
            // 
            this.lblListsPath.AutoSize = true;
            this.lblListsPath.Location = new System.Drawing.Point(40, 232);
            this.lblListsPath.Name = "lblListsPath";
            this.lblListsPath.Size = new System.Drawing.Size(57, 15);
            this.lblListsPath.TabIndex = 18;
            this.lblListsPath.Text = "Lists path";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(665, 256);
            this.Controls.Add(this.lblListsPath);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblPracticing);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.combSort);
            this.Controls.Add(this.dataGrid);
            this.Controls.Add(this.lblWords);
            this.Controls.Add(this.btnPractice);
            this.Controls.Add(this.btnRemoveWord);
            this.Controls.Add(this.btnAddWord);
            this.Controls.Add(this.btnAddList);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lab4";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAddList;
        private System.Windows.Forms.Button btnAddWord;
        private System.Windows.Forms.Button btnRemoveWord;
        private System.Windows.Forms.Button btnPractice;
        private System.Windows.Forms.Label lblWords;
        private System.Windows.Forms.DataGridView dataGrid;
        private System.Windows.Forms.ComboBox combSort;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblPracticing;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblListsPath;
    }
}

