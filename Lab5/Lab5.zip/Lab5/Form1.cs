﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5
{
    public partial class Form1 : Form
    {
        private int savedFilesCount = 0;   //gives information after
        private string savedFilePath = "";//saving images to a folder
        public Form1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            await ExtractAsync();
        }
        private async void txtUrl_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                await ExtractAsync();
            }
        }
        private async Task ExtractAsync()
        {
            try
            {              
                txtUrl.Enabled = false;
                btnExtract.Enabled = false;
                btnSave.Enabled = false;
                lblLinksCount.Text = "";
                lblStatus.Text = "Extracting";
                progressBar.Style = ProgressBarStyle.Marquee;
                progressBar.MarqueeAnimationSpeed = 20;
                listBox.Items.Clear();

                await GetHtmlStringAsync();

                if (listBox.Items.Count > 0)
                    btnSave.Enabled = true;
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK,
                   MessageBoxIcon.Error);
            }
            finally
            {
                txtUrl.Enabled = true;
                btnExtract.Enabled = true;
                lblStatus.Text = "Ready";
                progressBar.Style = ProgressBarStyle.Continuous;
            }
        }

        private async Task GetHtmlStringAsync()
        {
            string url = txtUrl.Text.ToLower();
            if (!url.EndsWith("/"))
                url += "/";

            if (!url.StartsWith("http://") && !url.StartsWith("https://"))
            {
                string tmp = "http://" + url;
                url = tmp;
            }

            string webString = await GetHttpStringAsync(url);

            //anpassad efter gp.se
            Regex regex = new Regex(@"<img(.*?)>", RegexOptions.IgnoreCase);
            MatchCollection matchCollection = regex.Matches(webString);

            for (int i = 0; i < matchCollection.Count; i++)
            {
                string s = matchCollection[i].Value;
                if (!s.Contains("http"))
                {                   
                    s = s.Remove(0, s.IndexOf("src=") + 5);//removes <img ... src="
                    s = s.Remove(s.IndexOf("\""), s.Length - s.IndexOf("\""));//removes ...">

                    if (s.StartsWith("/"))//url already ends with /
                        s = s.Remove(0, 1);

                    if (!string.IsNullOrEmpty(s) ||
                        !string.IsNullOrWhiteSpace(s))
                    {
                        listBox.Items.Add(url + s);
                    }     
                }
            }
            lblLinksCount.Text = listBox.Items.Count.ToString() + " images found";
        }

        private async Task<string> GetHttpStringAsync(string url)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                return await httpClient.GetStringAsync(url);
            }
            catch (WebException) { throw; }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                btnSave.Enabled = false;
                btnExtract.Enabled = false;
                txtUrl.Enabled = false;
                listBox.Enabled = false;
                if (folderBrowser.ShowDialog() == DialogResult.OK)
                {
                    savedFilePath = folderBrowser.SelectedPath;
                    await SaveAsync(folderBrowser.SelectedPath);
                }
            }
            catch (AggregateException ex)
            {
                MessageBox.Show(ex.Message, "Error",MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                progressBar.Style = ProgressBarStyle.Continuous;
                progressBar.Value = 0;
                lblStatus.Text = "Ready";
                btnSave.Enabled = true;
                btnExtract.Enabled = true;
                txtUrl.Enabled = true;
                listBox.Enabled = true;
                string img = savedFilesCount == 1 ? "image" : "images";
                if (savedFilesCount > 0)
                    MessageBox.Show($"{savedFilesCount} {img} saved in {savedFilePath}",
                                    "Save images", MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                savedFilesCount = 0;
            }
        }

        private async Task SaveAsync(string path)
        {
            if (!path.EndsWith("\\"))
                path += "\\";

            string[] items;
            if (listBox.SelectedItems.Count > 0)
            {
                items = new string[listBox.SelectedItems.Count];
                listBox.SelectedItems.CopyTo(items, 0);
            }
            else
            {
                items = new string[listBox.Items.Count];
                listBox.Items.CopyTo(items,0);
            }

            lblStatus.Text = "Saving";
            progressBar.Style = ProgressBarStyle.Marquee;
            progressBar.MarqueeAnimationSpeed = 20;

            try
            {
                List<Task<FileMod>> tasks = new List<Task<FileMod>>();

                for (int i = 0; i < items.Length; i++)
                {
                    tasks.Add(GetFileDataAsync(items[i].ToString()));
                }

                int imageCounter = 1;
                while (tasks.Count > 0)
                {
                    var task = await Task.WhenAny(tasks);
                    string targetFile = path + "Image " + imageCounter +
                        task.Result.FileExtesnsion;

                    await SaveToFileAsync(targetFile, task.Result.FileData);
                    savedFilesCount++;
                    tasks.Remove(task);
                    imageCounter++;
                }
            }
            catch (AggregateException) { throw; }
        }

        private async Task SaveToFileAsync(string path, byte[] data)
        {
            try
            {
                await File.WriteAllBytesAsync(path, data);
            }
            catch (IOException) { throw; }
        }

        private async Task<FileMod> GetFileDataAsync(string url)
        {
            HttpClient httpClient = new HttpClient();
            FileMod fileMod = new FileMod();

            string ext = url;
            if (ext.Contains("?"))
            {
                ext = ext.Remove(ext.IndexOf("?"), ext.Length - ext.IndexOf("?"));
            }
            fileMod.FileExtesnsion = Path.GetExtension(ext);

            try
            {
                httpClient.Timeout = TimeSpan.FromMinutes(1);
                fileMod.FileData = await httpClient.GetByteArrayAsync(url);
            }
            catch (AggregateException)
            {
                throw;
            }

            return fileMod;
        }
    }
}
