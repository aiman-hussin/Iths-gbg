﻿namespace Lab5
{
    class FileMod
    {
        public string FileExtesnsion { get; set; }
        public byte[] FileData { get; set; }
    }
}