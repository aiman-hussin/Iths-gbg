﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using ClassLibrary1;

namespace Lab2
{
    class Program
    {
        private static List<Shape> shapes = new List<Shape>();
        static void Main(string[] args)
        {
            bool run = true;
            while (run)
            {
                Console.WriteLine("\nChoose 1, 2, 3 or 4 from the menu:\n" +
                    "1. Generate 20 random shapes\n" +
                    "2. Generate 20 random shapes with a specific center point\n" +
                    "3. Loop through triangle's points with IEnumerable\n" +
                    "4. Exit");

                int val = int.Parse(Console.ReadLine());
                switch (val)
                {
                    case 1:
                        GenerataRandomShapes();
                        break;
                    case 2:
                        GenerateRandomShapesWithCenter();
                        break;
                    case 3:
                        TriangleIEnumerable();
                        break;
                    case 4:
                        run = false;
                        break;
                }
            }
        }

        private static void GenerataRandomShapes()
        {
            shapes.Clear();
            for (int i = 0; i < 20; i++)
            {
                shapes.Add(Shape.GenerateShape());
            }
            PrintShapes();
        }

        private static void GenerateRandomShapesWithCenter()
        {
            List<string> values = new List<string>();
            Console.WriteLine($"Enter center in format x,y,z");

            values.Clear();
            values = Console.ReadLine().Split(',').ToList();
            float x, y, z;
            x = float.Parse(values[0]);
            y = float.Parse(values[1]);
            z = float.Parse(values[2]);
            Vector3 v3 = new Vector3(x, y, z);

            shapes.Clear();
            for (int i = 0; i < 20; i++)
            {
                shapes.Add(Shape.GenerateShape(v3));
            }
            PrintShapes();
        }

        private static void PrintShapes()
        {
            float omkrets = 0;
            float avereageArea = 0;
            float largest3dShapeVolume = 0;

            for (int i = 0; i < shapes.Count; i++)
            {
                Shape shape = shapes[i];

                if (shape is Circle)
                {
                    Circle circle = (Circle)shape;
                    avereageArea += circle.Area;
                    Console.WriteLine(i + 1 + ". " + circle.ToString());
                }
                else if (shape is Cuboid)
                {
                    Cuboid cuboid = (Cuboid)shape;
                    avereageArea += cuboid.Area;
                    if (cuboid.Volume > largest3dShapeVolume)
                    {
                        largest3dShapeVolume = cuboid.Volume;
                    }
                    Console.WriteLine(i + 1 + ". " + cuboid.ToString());
                }
                else if (shape is Rectangle)
                {
                    Rectangle rectangle = (Rectangle)shape;
                    avereageArea += rectangle.Area;
                    Console.WriteLine(i + 1 + ". " + rectangle.ToString());
                }
                else if (shape is Sphere)
                {
                    Sphere sphere = (Sphere)shape;
                    avereageArea += sphere.Area;
                    if (sphere.Volume > largest3dShapeVolume)
                    {
                        largest3dShapeVolume = sphere.Volume;
                    }
                    Console.WriteLine(i + 1 + ". " + sphere.ToString());
                }
                else if (shape is Triangle)
                {
                    Triangle triangle = (Triangle)shape;
                    avereageArea += triangle.Area;
                    omkrets += triangle.Omkrets;
                    Console.WriteLine(i + 1 + ". " + triangle.ToString());
                }
            }

            avereageArea /= shapes.Count;
            avereageArea = (float)Math.Round(avereageArea, 1);
            omkrets = (float)Math.Round(omkrets, 1);
            largest3dShapeVolume = (float)Math.Round(largest3dShapeVolume, 1);
            Console.WriteLine("*****************************");
            Console.WriteLine(" Omkrets for all triangles is: " + omkrets);
            Console.WriteLine(" Average area is: " + avereageArea);
            Console.WriteLine(" Biggist volume is: " + largest3dShapeVolume);
        }

        private static void TriangleIEnumerable()
        {
            List<string> values = new List<string>();

            Vector2[] points = new Vector2[3];
            points[0] = new Vector2(0, 0);
            points[1] = new Vector2(0, 0);
            points[2] = new Vector2(0, 0);

            for (int i = 0; i < points.Length; i++)
            {
                Console.WriteLine($"Enter point {i + 1} in format x,y");
                values.Clear();
                values = Console.ReadLine().Split(',').ToList();
                points[i].X = float.Parse(values[0]);
                points[i].Y = float.Parse(values[1]);
            }

            Triangle t = new Triangle(points[0], points[1], points[2]);
            Console.WriteLine();
            foreach (Vector2 v in t)
            {
                Console.WriteLine(v);
            }
        }
    }
}
