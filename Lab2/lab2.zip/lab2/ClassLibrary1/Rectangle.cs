﻿using System;
using System.Numerics;

namespace ClassLibrary1
{
    public class Rectangle : Shape2D
    {
        private Vector2 mCenter;
        private Vector2 mSize;

        public bool IsSquare { get; } = false;

        public Rectangle(Vector2 center, Vector2 size)
        {
            mCenter = center;
            mSize = size;
        }
        public Rectangle(Vector2 center, float width)
        {
            mCenter = center;
            mSize.X = width;
            mSize.Y = width;
            IsSquare = true;
        }

        public override float Circumference
        {
            get
            {
                if (IsSquare)
                {
                    // formula for circumference of a square
                    //https://www-formula.com/geometry/radius-circumcircle/radius-circumcircle-square    
                    return (float)(mSize.X / Math.Sqrt(2));
                }
                // formula for circumference of a rectangle
                // https://www-formula.com/geometry/radius-circumcircle/radius-circumcircle-rectangle
                float z = (float)(Math.Sqrt(Math.Pow(mSize.X, 2) +
                    Math.Pow(mSize.Y, 2)) / 2);
                return z;
            }
        }

        public override Vector3 Center
        {
            get
            {
                return new Vector3(mCenter.X, mCenter.Y, 0);
            }
        }

        public override float Area
        {
            get
            {
                return mSize.X * mSize.Y;
            }
        }

        public override string ToString()
        {
            string type = "rectangle";
            if (IsSquare)
            {
                type = "square";
            }
            return type + " @(" + mCenter.X + ", " + mCenter.Y + "): w = " +
                mSize.X + " h = " + mSize.Y + ", A = " +Math.Round(Area,1) +
                ", C = " +Math.Round(Circumference,1);
        }
    }
}
