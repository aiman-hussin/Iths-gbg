﻿namespace ClassLibrary1
{
    public abstract class Shape2D:Shape
    {
        public abstract float Circumference { get; }
    }
}
