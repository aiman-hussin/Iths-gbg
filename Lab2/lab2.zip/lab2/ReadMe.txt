Labb2

Jag har automatiserat min lösning genom en meny för testnings skull och har lämnat den kvar för jag tycker att den är snygg! Detta har medfört lite mer kod i Program.cs. Ingen felhantering implementerat,  en felinmättning krascher programmet.

Har lagt lite mer information när man anropar ToString for att skriva ut information om objekten. A = area, V = volume, C = circumference, O = omkrets.

Enligt 'omkrets' definition så är det betyder summan på samtliga triangels sidor. Om man vill att programmet ska summa circumference istället då går det att byta Omkrets mot Circumference i Program.cs linje 119

Jag har använt Math.Round flera gånger i ToString metod i samtliga figurklasser istället för att använda den vid return för att få noggranna beräkningar sen.