﻿using System;
using System.Numerics;

namespace ClassLibrary1
{
    public class Circle : Shape2D
    {
        private Vector2 mCenter;
        private float mRadius;

        public Circle(Vector2 center, float radius)
        {
            mCenter = center;
            mRadius = radius;
        }
        public override float Circumference
        {
            get
            {

                return (float)(Math.PI * mRadius * 2);
            }
        }

        public override Vector3 Center
        {
            get
            {
                return new Vector3(mCenter.X, mCenter.Y, 0.0f);
            }
        }

        public override float Area
        {
            get
            {
                return (float)(Math.PI * (mRadius * mRadius));
            }
        }

        public override string ToString()
        {
            return "circle @(" + mCenter.X + ", " + mCenter.Y +
                "): r = " + mRadius + ", A = " + Math.Round(Area,1) + 
                ", C = " + Math.Round(Circumference,1);
        }
    }
}
