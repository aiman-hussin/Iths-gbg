﻿using System;
using System.Numerics;

namespace ClassLibrary1
{
    public class Sphere : Shape3D
    {
        private Vector3 mCenter;
        private float mRadius;

        public Sphere(Vector3 center, float radius)
        {
            mCenter = center;
            mRadius = radius;
        }

        public override float Volume
        {
            get
            {
                return (float)(4 * Math.PI * Math.Pow(mRadius, 3) / 3);
            }
        }

        public override Vector3 Center
        {
            get
            {
                return mCenter;
            }
        }

        public override float Area
        {
            get
            {
                return (float)(4 * Math.PI * Math.Pow(mRadius, 2));
            }
        }

        public override string ToString()
        {
            return "sphere @(" + mCenter.X + ", " + mCenter.Y + ", " +
                mCenter.Z + "): r = " + mRadius + ", A = " +Math.Round(Area,1) + 
                ", V = " + Math.Round(Volume,1);
        }
    }
}
