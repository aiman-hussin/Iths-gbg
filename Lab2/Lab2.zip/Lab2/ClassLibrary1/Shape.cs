﻿using System;
using System.Numerics;

namespace ClassLibrary1
{
    public abstract class Shape
    {
        public abstract Vector3 Center { get; }
        public abstract float Area { get; }

        public static Shape GenerateShape()
        {
            int min = 0;
            int max = 21;

            Random random = new Random();
            int rand = random.Next(0, 7);

            int randX = random.Next(min, max);
            int randY = random.Next(min, max);
            int randZ = random.Next(min, max);
            int randWidth = random.Next(min + 1, max); //we add 1 to avoid getting 0
            int randHeight = random.Next(min + 1, max);
            int randLength = random.Next(min + 1, max);

            switch (rand)
            {
                case 0:
                    Circle circle =
                        new Circle(new Vector2(randX, randY), randWidth);
                    return circle;

                case 1:
                    if (randWidth == randHeight && randHeight == randLength)
                    {
                        randLength += random.Next(min + 1, max);
                    }
                    Cuboid cuboid =
                        new Cuboid(new Vector3(randX, randY, randZ),
                        new Vector3(randWidth, randHeight, randLength));
                    return cuboid;

                case 2:
                    Cuboid cube =
                        new Cuboid(new Vector3(randX, randY, randZ),
                        randWidth);
                    return cube;

                case 3:
                    if (randWidth == randHeight)
                    {
                        randHeight += random.Next(min + 1, max);
                    }
                    Rectangle rectangle =
                        new Rectangle(new Vector2(randX, randY),
                        new Vector2(randWidth, randHeight));
                    return rectangle;

                case 4:
                    Rectangle squar =
                        new Rectangle(new Vector2(randX, randY),
                        randWidth);
                    return squar;

                case 5:
                    Sphere sphere =
                        new Sphere(new Vector3(randX, randY, randZ),
                        randWidth);
                    return sphere;

                case 6:
                    float[][] points = GetTrianglePoints(min, max);
                    Triangle triangle =
                        new Triangle(new Vector2(points[0][0], points[0][1]),
                        new Vector2(points[1][0], points[1][1]),
                        new Vector2(points[2][0], points[2][1]));
                    return triangle;
            }
            return null;
        }


        public static Shape GenerateShape(Vector3 center)
        {

            int min = 0;
            int max = 21;
            Random random = new Random();
            int rand = random.Next(0, 7);

            //int randX = random.Next(min, max);
            //int randY = random.Next(min, max);
            //int randZ = random.Next(min, max);
            int randWidth = random.Next(min, max);
            int randHeight = random.Next(min, max);
            int randLength = random.Next(min, max);
            switch (rand)
            {
                case 0:

                    Circle circle = new Circle(new Vector2(center.X, center.Y),
                        randWidth);
                    return circle;

                case 1:
                    if (randWidth == randHeight && randHeight == randLength)
                    {
                        randLength += random.Next(min + 1, max);
                    }
                    Cuboid cuboid =
                        new Cuboid(center,
                        new Vector3(randWidth, randHeight, randLength));
                    return cuboid;

                case 2:
                    Cuboid cube = new Cuboid(center, randWidth);
                    return cube;

                case 3:
                    if (randWidth == randHeight)
                    {
                        randHeight += random.Next(min + 1, max);
                    }
                    Vector2 mCenter = new Vector2(center.X, center.Y);
                    Rectangle rectangle =
                        new Rectangle(new Vector2(center.X, center.Y),
                        new Vector2(randWidth, randHeight));
                    return rectangle;

                case 4:
                    Rectangle squar =
                        new Rectangle(new Vector2(center.X, center.Y),
                        randWidth);
                    return squar;

                case 5:
                    Sphere sphere =
                        new Sphere(center,
                        randWidth);
                    return sphere;

                case 6:
                    float[][] points = GetTrianglePoints(min, max);

                    MoveTriangleToGivenCenter(ref points, GetTriangleCenter(points),
                        new Vector2(center.X, center.Y));

                    Triangle triangle =
                        new Triangle(new Vector2(points[0][0], points[0][1]),
                        new Vector2(points[1][0], points[1][1]),
                        new Vector2(points[2][0], points[2][1]));
                    return triangle;
            }
            return null;
        }

        private static float[][] GetTrianglePoints(int min, int max)
        {
            Vector2 p1 = new Vector2(0, 0), p2 = new Vector2(0, 0),
                         p3 = new Vector2(0, 0);
            bool similarPoints = true;
            Random random = new Random();
            float[][] points = new float[3][];
            points[0] = new float[2];
            points[1] = new float[2];
            points[2] = new float[2];

            while (similarPoints)
            {
                p1.X = random.Next(min, max);
                p1.Y = random.Next(min, max);

                p2.X = random.Next(min, max);
                p2.Y = random.Next(min, max);

                p3.X = random.Next(min, max);
                p3.Y = random.Next(min, max);

                if (p1 != p2 && p1 != p3 && p2 != p3)
                {
                    similarPoints = false;
                }
            }

            points[0][0] = p1.X;
            points[0][1] = p1.Y;

            points[1][0] = p2.X;
            points[1][1] = p2.Y;

            points[2][0] = p3.X;
            points[2][1] = p3.Y;

            return (float[][])points.Clone();
        }
        private static Vector2 GetTriangleCenter(float[][] points)
        {
            float x = (float)Math.Round((points[0][0] + points[1][0] +
                points[2][0]) / 3, 1);
            float y = (float)Math.Round((points[0][1] + points[1][1] +
                points[2][1]) / 3, 1);
            return new Vector2(x, y);
        }

        private static float[][] MoveTriangleToGivenCenter(ref float[][] points,
            Vector2 center, Vector2 newCenter)
        {
            float offsetX = 0, offsetY = 0;

            if (newCenter.X > center.X)
            {
                offsetX = newCenter.X - center.X;
                center.X += offsetX;
                points[0][0] += offsetX;
                points[1][0] += offsetX;
                points[2][0] += offsetX;
            }
            else if (center.X > newCenter.X)
            {
                offsetX = center.X - newCenter.X;
                center.X -= offsetX;
                points[0][0] -= offsetX;
                points[1][0] -= offsetX;
                points[2][0] -= offsetX;
            }

            if (newCenter.Y > center.Y)
            {
                offsetY = newCenter.Y - center.Y;
                center.Y += offsetY;
                points[0][1] += offsetY;
                points[1][1] += offsetY;
                points[2][1] += offsetY;
            }
            else if (center.Y > newCenter.Y)
            {
                offsetY = center.Y - newCenter.Y;
                center.Y -= offsetY;
                points[0][1] -= offsetY;
                points[1][1] -= offsetY;
                points[2][1] -= offsetY;
            }

            return points;
        }
    }
}
