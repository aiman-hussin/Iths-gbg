﻿using System;
using System.Numerics;

namespace ClassLibrary1
{
    public class Cuboid : Shape3D
    {
        private Vector3 mCenter;
        private Vector3 mSize;

        public bool IsCube { get; } = false;

        public Cuboid(Vector3 center, Vector3 size)
        {
            mCenter = center;
            mSize = size;
        }
        public Cuboid(Vector3 center, float width)
        {
            mCenter = center;
            mSize.X = width;
            mSize.Y = width;
            mSize.Z = width;
            IsCube = true;
        }
        public override float Volume
        {
            get
            {
                return mSize.X * mSize.Y * mSize.Z;
            }
        }

        public override Vector3 Center
        {
            get
            {
                return mCenter;
            }
        }

        public override float Area
        {
            get
            {
                if (IsCube)
                {
                    //formula for cube area
                    //https://sciencing.com/calculate-area-cube-5137293.html
                    return (float)(6 * Math.Pow(mSize.X, 2));
                }
                // formula for Cuboid area 
                //https://www.geogebra.org/m/wpW5cVHt
                return 2 * ((mSize.Z * mSize.X) +
                    (mSize.X * mSize.Y) + (mSize.Z * mSize.Y));
            }
        }

        public override string ToString()
        {
            string type = "cuboid";
            if (IsCube)
            {
                type = "cube";
            }
            return type + " @(" + mCenter.X + ", " + mCenter.Y + ", " +
                mCenter.Z + "): w = " + mSize.X + " h = " + mSize.Y +
                " l = " + mSize.Z + ", A = " + Math.Round(Area, 1) +
                ", V = " +Math.Round(Volume,1);
        }
    }
}
