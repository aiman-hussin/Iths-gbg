﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;

namespace ClassLibrary1
{
    public class Triangle : Shape2D, IEnumerable<Vector2>
    {
        private List<Vector2> _points = new List<Vector2>();
        private Vector2 mP1, mP2, mP3;
        float sideA, sideB, sideC;

        public Triangle(Vector2 p1, Vector2 p2, Vector2 p3)
        {
            mP1 = p1;
            mP2 = p2;
            mP3 = p3;

            _points.Add(p1);
            _points.Add(p2);
            _points.Add(p3);

            sideA = Vector2.Distance(p1, p2);
            sideB = Vector2.Distance(p2, p3);
            sideC = Vector2.Distance(p3, p1);
        }

        public override float Circumference
        {
            get
            {
                // formula for circumference when we know length of
                // all sides of a triangel
                //https://www.mathopenref.com/trianglecircumcircle.html
                float z = (float)(sideA * sideB * sideC /
                    Math.Sqrt((sideA + sideB + sideC) *
                    (sideB + sideC - sideA) * (sideC + sideA - sideB) *
                    (sideA + sideB - sideC)));
                return z;
            }
        }

        public override Vector3 Center
        {
            get
            {
                //triangle center formula
                //https://www.vedantu.com/maths/centroid
                float x = (float)Math.Round((mP1.X + mP2.X + mP3.X) / 3, 1);
                float y = (float)Math.Round((mP1.Y + mP2.Y + mP3.Y) / 3, 1);
                return new Vector3(x, y, 0);
            }
        }

        public override float Area
        {
            get
            {
                // Heron's Formula for the area of a triangle
                // https://www.mathopenref.com/heronsformula.html
                float p = (sideA + sideB + sideC) / 2;
                float area = (float)Math.Sqrt(p * (p - sideA) *
                    (p - sideB) * (p - sideC));
                return area;
            }
        }

        public float Omkrets
        {
            get
            {
                //omkrets = summan av triangels sidor
                return sideA + sideB + sideC;
            }
        }

        public override string ToString()
        {
            return "triangle @(" + Center.X + ", " + Center.Y + "): " +
                "p1(" + Math.Round( mP1.X,1) + ", " + Math.Round( mP1.Y,1) +
                 "), p2(" + Math.Round(mP2.X, 1) + ", " + Math.Round( mP2.Y,1) +
                 "), p3(" + Math.Round(mP3.X, 1) + ", " + Math.Round( mP3.Y,1) +
                 ")" + ", A = " + Math.Round(Area, 1) + ", O = " +
                  Math.Round(Omkrets, 1) + ", C = " + Math.Round(Circumference, 1);
        }

        IEnumerator<Vector2> IEnumerable<Vector2>.GetEnumerator()
        {
            return _points.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return _points.GetEnumerator();
        }
    }
}
