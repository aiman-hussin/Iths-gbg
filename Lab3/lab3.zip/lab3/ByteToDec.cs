﻿using System;

namespace lab3
{
    public static class ByteToDec
    {
        public static int Png(int[] bytes)
        {
            string s = "";

            for (int i = 0; i < bytes.Length; i++)
            {
                s += bytes[i].ToString("x2");
            }

            int p = int.Parse(s, System.Globalization.NumberStyles.HexNumber);

            return p;
        }

        public static int Bmp(int[] bytes)
        {
            string s = "";

            for (int i = bytes.Length - 1; i >= 0; i--)
            {
                s += bytes[i].ToString("x2");
            }

            int p = int.Parse(s, System.Globalization.NumberStyles.HexNumber);

            return p;
        }
    }
}
