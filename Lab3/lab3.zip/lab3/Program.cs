﻿using System;
using System.Collections.Generic;
using System.IO;

namespace lab3
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> byts = new List<int>();

            Console.WriteLine("File path:");
            string path = Console.ReadLine();

            int c;
            int i = 0;

            try
            {
                FileStream fileStream = new FileStream(path, FileMode.Open);
                using (fileStream)
                {    
                    // read only 26 bytes that are required for the id, width and height
                    while ((c = fileStream.ReadByte()) != -1 && i < 26)
                    {
                        byts.Add(c);
                        i++;
                    }
                    //check ID bytes by their int values
                    if (byts[0] == 137 && byts[1] == 80 && byts[2] == 78 &&
                        byts[3] == 71)
                    {
                        int[] w = new int[] { byts[16], byts[17], byts[18], byts[19] };
                        int[] h = new int[] { byts[20], byts[21], byts[22], byts[23] };
                        Console.WriteLine($"Png file width {ByteToDec.Png(w)} " +
                            $"heigh {ByteToDec.Png(h)}");
                    }
                    else if (byts[0] == 66 && byts[1] == 77)
                    {
                        int[] w = new int[] { byts[18], byts[19], byts[20], byts[21] };
                        int[] h = new int[] { byts[22], byts[23], byts[24], byts[25] };
                        Console.WriteLine($"Bmp file width {ByteToDec.Bmp(w)} " +
                            $"heigh {ByteToDec.Bmp(h)}");
                    }
                    else
                    {
                        Console.WriteLine("Unkonown file format");
                    }
                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine($"File {0} not found", e.FileName);
            }
            catch (ArgumentOutOfRangeException)
            {
                //if the header doesn't contain all the required information
                Console.WriteLine("Invalid file");
            }
            catch (Exception)
            {
                Console.WriteLine("Internal error, call customer service");
            }
        }
    }
}
